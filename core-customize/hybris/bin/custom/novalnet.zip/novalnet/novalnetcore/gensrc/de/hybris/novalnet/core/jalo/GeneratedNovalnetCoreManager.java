/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 28, 2020, 12:06:32 PM                   ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package de.hybris.novalnet.core.jalo;

import de.hybris.novalnet.core.constants.NovalnetCoreConstants;
import de.hybris.novalnet.core.jalo.NovalnetBarzahlenPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetCallbackInfo;
import de.hybris.novalnet.core.jalo.NovalnetCreditCardPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetDirectDebitSepaPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetEpsPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetGiropayPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetGuaranteedDirectDebitSepaPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetGuaranteedInvoicePaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetIdealPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetInstantBankTransferPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetInvoicePaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetPayPalPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetPaymentInfo;
import de.hybris.novalnet.core.jalo.NovalnetPaymentRefInfo;
import de.hybris.novalnet.core.jalo.NovalnetPostFinanceCardPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetPostFinancePaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetPrepaymentPaymentMode;
import de.hybris.novalnet.core.jalo.NovalnetPrzelewy24PaymentMode;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import de.hybris.platform.store.BaseStore;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type <code>NovalnetCoreManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedNovalnetCoreManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("novalnetAPIKey", AttributeMode.INITIAL);
		tmp.put("novalnetTariffId", AttributeMode.INITIAL);
		tmp.put("novalnetPaymentAccessKey", AttributeMode.INITIAL);
		tmp.put("novalnetClientKey", AttributeMode.INITIAL);
		tmp.put("novalnetPaymentLogo", AttributeMode.INITIAL);
		tmp.put("novalnetVendorscriptTestMode", AttributeMode.INITIAL);
		tmp.put("novalnetVendorscriptToEmailAddress", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.store.BaseStore", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	public NovalnetBarzahlenPaymentMode createNovalnetBarzahlenPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETBARZAHLENPAYMENTMODE );
			return (NovalnetBarzahlenPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetBarzahlenPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetBarzahlenPaymentMode createNovalnetBarzahlenPaymentMode(final Map attributeValues)
	{
		return createNovalnetBarzahlenPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetCallbackInfo createNovalnetCallbackInfo(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETCALLBACKINFO );
			return (NovalnetCallbackInfo)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetCallbackInfo : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetCallbackInfo createNovalnetCallbackInfo(final Map attributeValues)
	{
		return createNovalnetCallbackInfo( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetCreditCardPaymentMode createNovalnetCreditCardPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETCREDITCARDPAYMENTMODE );
			return (NovalnetCreditCardPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetCreditCardPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetCreditCardPaymentMode createNovalnetCreditCardPaymentMode(final Map attributeValues)
	{
		return createNovalnetCreditCardPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetDirectDebitSepaPaymentMode createNovalnetDirectDebitSepaPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETDIRECTDEBITSEPAPAYMENTMODE );
			return (NovalnetDirectDebitSepaPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetDirectDebitSepaPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetDirectDebitSepaPaymentMode createNovalnetDirectDebitSepaPaymentMode(final Map attributeValues)
	{
		return createNovalnetDirectDebitSepaPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetEpsPaymentMode createNovalnetEpsPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETEPSPAYMENTMODE );
			return (NovalnetEpsPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetEpsPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetEpsPaymentMode createNovalnetEpsPaymentMode(final Map attributeValues)
	{
		return createNovalnetEpsPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetGiropayPaymentMode createNovalnetGiropayPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETGIROPAYPAYMENTMODE );
			return (NovalnetGiropayPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetGiropayPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetGiropayPaymentMode createNovalnetGiropayPaymentMode(final Map attributeValues)
	{
		return createNovalnetGiropayPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetGuaranteedDirectDebitSepaPaymentMode createNovalnetGuaranteedDirectDebitSepaPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETGUARANTEEDDIRECTDEBITSEPAPAYMENTMODE );
			return (NovalnetGuaranteedDirectDebitSepaPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetGuaranteedDirectDebitSepaPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetGuaranteedDirectDebitSepaPaymentMode createNovalnetGuaranteedDirectDebitSepaPaymentMode(final Map attributeValues)
	{
		return createNovalnetGuaranteedDirectDebitSepaPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetGuaranteedInvoicePaymentMode createNovalnetGuaranteedInvoicePaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETGUARANTEEDINVOICEPAYMENTMODE );
			return (NovalnetGuaranteedInvoicePaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetGuaranteedInvoicePaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetGuaranteedInvoicePaymentMode createNovalnetGuaranteedInvoicePaymentMode(final Map attributeValues)
	{
		return createNovalnetGuaranteedInvoicePaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetIdealPaymentMode createNovalnetIdealPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETIDEALPAYMENTMODE );
			return (NovalnetIdealPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetIdealPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetIdealPaymentMode createNovalnetIdealPaymentMode(final Map attributeValues)
	{
		return createNovalnetIdealPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetInstantBankTransferPaymentMode createNovalnetInstantBankTransferPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETINSTANTBANKTRANSFERPAYMENTMODE );
			return (NovalnetInstantBankTransferPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetInstantBankTransferPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetInstantBankTransferPaymentMode createNovalnetInstantBankTransferPaymentMode(final Map attributeValues)
	{
		return createNovalnetInstantBankTransferPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetInvoicePaymentMode createNovalnetInvoicePaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETINVOICEPAYMENTMODE );
			return (NovalnetInvoicePaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetInvoicePaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetInvoicePaymentMode createNovalnetInvoicePaymentMode(final Map attributeValues)
	{
		return createNovalnetInvoicePaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPaymentInfo createNovalnetPaymentInfo(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPAYMENTINFO );
			return (NovalnetPaymentInfo)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPaymentInfo : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPaymentInfo createNovalnetPaymentInfo(final Map attributeValues)
	{
		return createNovalnetPaymentInfo( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPaymentRefInfo createNovalnetPaymentRefInfo(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPAYMENTREFINFO );
			return (NovalnetPaymentRefInfo)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPaymentRefInfo : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPaymentRefInfo createNovalnetPaymentRefInfo(final Map attributeValues)
	{
		return createNovalnetPaymentRefInfo( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPayPalPaymentMode createNovalnetPayPalPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPAYPALPAYMENTMODE );
			return (NovalnetPayPalPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPayPalPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPayPalPaymentMode createNovalnetPayPalPaymentMode(final Map attributeValues)
	{
		return createNovalnetPayPalPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPostFinanceCardPaymentMode createNovalnetPostFinanceCardPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPOSTFINANCECARDPAYMENTMODE );
			return (NovalnetPostFinanceCardPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPostFinanceCardPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPostFinanceCardPaymentMode createNovalnetPostFinanceCardPaymentMode(final Map attributeValues)
	{
		return createNovalnetPostFinanceCardPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPostFinancePaymentMode createNovalnetPostFinancePaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPOSTFINANCEPAYMENTMODE );
			return (NovalnetPostFinancePaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPostFinancePaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPostFinancePaymentMode createNovalnetPostFinancePaymentMode(final Map attributeValues)
	{
		return createNovalnetPostFinancePaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPrepaymentPaymentMode createNovalnetPrepaymentPaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPREPAYMENTPAYMENTMODE );
			return (NovalnetPrepaymentPaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPrepaymentPaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPrepaymentPaymentMode createNovalnetPrepaymentPaymentMode(final Map attributeValues)
	{
		return createNovalnetPrepaymentPaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	public NovalnetPrzelewy24PaymentMode createNovalnetPrzelewy24PaymentMode(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( NovalnetCoreConstants.TC.NOVALNETPRZELEWY24PAYMENTMODE );
			return (NovalnetPrzelewy24PaymentMode)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating NovalnetPrzelewy24PaymentMode : "+e.getMessage(), 0 );
		}
	}
	
	public NovalnetPrzelewy24PaymentMode createNovalnetPrzelewy24PaymentMode(final Map attributeValues)
	{
		return createNovalnetPrzelewy24PaymentMode( getSession().getSessionContext(), attributeValues );
	}
	
	@Override
	public String getName()
	{
		return NovalnetCoreConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetAPIKey</code> attribute.
	 * @return the novalnetAPIKey
	 */
	public String getNovalnetAPIKey(final SessionContext ctx, final BaseStore item)
	{
		return (String)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETAPIKEY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetAPIKey</code> attribute.
	 * @return the novalnetAPIKey
	 */
	public String getNovalnetAPIKey(final BaseStore item)
	{
		return getNovalnetAPIKey( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetAPIKey</code> attribute. 
	 * @param value the novalnetAPIKey
	 */
	public void setNovalnetAPIKey(final SessionContext ctx, final BaseStore item, final String value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETAPIKEY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetAPIKey</code> attribute. 
	 * @param value the novalnetAPIKey
	 */
	public void setNovalnetAPIKey(final BaseStore item, final String value)
	{
		setNovalnetAPIKey( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetClientKey</code> attribute.
	 * @return the novalnetClientKey
	 */
	public String getNovalnetClientKey(final SessionContext ctx, final BaseStore item)
	{
		return (String)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETCLIENTKEY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetClientKey</code> attribute.
	 * @return the novalnetClientKey
	 */
	public String getNovalnetClientKey(final BaseStore item)
	{
		return getNovalnetClientKey( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetClientKey</code> attribute. 
	 * @param value the novalnetClientKey
	 */
	public void setNovalnetClientKey(final SessionContext ctx, final BaseStore item, final String value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETCLIENTKEY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetClientKey</code> attribute. 
	 * @param value the novalnetClientKey
	 */
	public void setNovalnetClientKey(final BaseStore item, final String value)
	{
		setNovalnetClientKey( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetPaymentAccessKey</code> attribute.
	 * @return the novalnetPaymentAccessKey
	 */
	public String getNovalnetPaymentAccessKey(final SessionContext ctx, final BaseStore item)
	{
		return (String)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETPAYMENTACCESSKEY);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetPaymentAccessKey</code> attribute.
	 * @return the novalnetPaymentAccessKey
	 */
	public String getNovalnetPaymentAccessKey(final BaseStore item)
	{
		return getNovalnetPaymentAccessKey( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetPaymentAccessKey</code> attribute. 
	 * @param value the novalnetPaymentAccessKey
	 */
	public void setNovalnetPaymentAccessKey(final SessionContext ctx, final BaseStore item, final String value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETPAYMENTACCESSKEY,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetPaymentAccessKey</code> attribute. 
	 * @param value the novalnetPaymentAccessKey
	 */
	public void setNovalnetPaymentAccessKey(final BaseStore item, final String value)
	{
		setNovalnetPaymentAccessKey( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetPaymentLogo</code> attribute.
	 * @return the novalnetPaymentLogo
	 */
	public Boolean isNovalnetPaymentLogo(final SessionContext ctx, final BaseStore item)
	{
		return (Boolean)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETPAYMENTLOGO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetPaymentLogo</code> attribute.
	 * @return the novalnetPaymentLogo
	 */
	public Boolean isNovalnetPaymentLogo(final BaseStore item)
	{
		return isNovalnetPaymentLogo( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetPaymentLogo</code> attribute. 
	 * @return the novalnetPaymentLogo
	 */
	public boolean isNovalnetPaymentLogoAsPrimitive(final SessionContext ctx, final BaseStore item)
	{
		Boolean value = isNovalnetPaymentLogo( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetPaymentLogo</code> attribute. 
	 * @return the novalnetPaymentLogo
	 */
	public boolean isNovalnetPaymentLogoAsPrimitive(final BaseStore item)
	{
		return isNovalnetPaymentLogoAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetPaymentLogo</code> attribute. 
	 * @param value the novalnetPaymentLogo
	 */
	public void setNovalnetPaymentLogo(final SessionContext ctx, final BaseStore item, final Boolean value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETPAYMENTLOGO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetPaymentLogo</code> attribute. 
	 * @param value the novalnetPaymentLogo
	 */
	public void setNovalnetPaymentLogo(final BaseStore item, final Boolean value)
	{
		setNovalnetPaymentLogo( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetPaymentLogo</code> attribute. 
	 * @param value the novalnetPaymentLogo
	 */
	public void setNovalnetPaymentLogo(final SessionContext ctx, final BaseStore item, final boolean value)
	{
		setNovalnetPaymentLogo( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetPaymentLogo</code> attribute. 
	 * @param value the novalnetPaymentLogo
	 */
	public void setNovalnetPaymentLogo(final BaseStore item, final boolean value)
	{
		setNovalnetPaymentLogo( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetTariffId</code> attribute.
	 * @return the novalnetTariffId
	 */
	public Integer getNovalnetTariffId(final SessionContext ctx, final BaseStore item)
	{
		return (Integer)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETTARIFFID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetTariffId</code> attribute.
	 * @return the novalnetTariffId
	 */
	public Integer getNovalnetTariffId(final BaseStore item)
	{
		return getNovalnetTariffId( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @return the novalnetTariffId
	 */
	public int getNovalnetTariffIdAsPrimitive(final SessionContext ctx, final BaseStore item)
	{
		Integer value = getNovalnetTariffId( ctx,item );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @return the novalnetTariffId
	 */
	public int getNovalnetTariffIdAsPrimitive(final BaseStore item)
	{
		return getNovalnetTariffIdAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @param value the novalnetTariffId
	 */
	public void setNovalnetTariffId(final SessionContext ctx, final BaseStore item, final Integer value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETTARIFFID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @param value the novalnetTariffId
	 */
	public void setNovalnetTariffId(final BaseStore item, final Integer value)
	{
		setNovalnetTariffId( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @param value the novalnetTariffId
	 */
	public void setNovalnetTariffId(final SessionContext ctx, final BaseStore item, final int value)
	{
		setNovalnetTariffId( ctx, item, Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetTariffId</code> attribute. 
	 * @param value the novalnetTariffId
	 */
	public void setNovalnetTariffId(final BaseStore item, final int value)
	{
		setNovalnetTariffId( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute.
	 * @return the novalnetVendorscriptTestMode
	 */
	public Boolean isNovalnetVendorscriptTestMode(final SessionContext ctx, final BaseStore item)
	{
		return (Boolean)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETVENDORSCRIPTTESTMODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute.
	 * @return the novalnetVendorscriptTestMode
	 */
	public Boolean isNovalnetVendorscriptTestMode(final BaseStore item)
	{
		return isNovalnetVendorscriptTestMode( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @return the novalnetVendorscriptTestMode
	 */
	public boolean isNovalnetVendorscriptTestModeAsPrimitive(final SessionContext ctx, final BaseStore item)
	{
		Boolean value = isNovalnetVendorscriptTestMode( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @return the novalnetVendorscriptTestMode
	 */
	public boolean isNovalnetVendorscriptTestModeAsPrimitive(final BaseStore item)
	{
		return isNovalnetVendorscriptTestModeAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @param value the novalnetVendorscriptTestMode
	 */
	public void setNovalnetVendorscriptTestMode(final SessionContext ctx, final BaseStore item, final Boolean value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETVENDORSCRIPTTESTMODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @param value the novalnetVendorscriptTestMode
	 */
	public void setNovalnetVendorscriptTestMode(final BaseStore item, final Boolean value)
	{
		setNovalnetVendorscriptTestMode( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @param value the novalnetVendorscriptTestMode
	 */
	public void setNovalnetVendorscriptTestMode(final SessionContext ctx, final BaseStore item, final boolean value)
	{
		setNovalnetVendorscriptTestMode( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptTestMode</code> attribute. 
	 * @param value the novalnetVendorscriptTestMode
	 */
	public void setNovalnetVendorscriptTestMode(final BaseStore item, final boolean value)
	{
		setNovalnetVendorscriptTestMode( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptToEmailAddress</code> attribute.
	 * @return the novalnetVendorscriptToEmailAddress
	 */
	public String getNovalnetVendorscriptToEmailAddress(final SessionContext ctx, final BaseStore item)
	{
		return (String)item.getProperty( ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETVENDORSCRIPTTOEMAILADDRESS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>BaseStore.novalnetVendorscriptToEmailAddress</code> attribute.
	 * @return the novalnetVendorscriptToEmailAddress
	 */
	public String getNovalnetVendorscriptToEmailAddress(final BaseStore item)
	{
		return getNovalnetVendorscriptToEmailAddress( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptToEmailAddress</code> attribute. 
	 * @param value the novalnetVendorscriptToEmailAddress
	 */
	public void setNovalnetVendorscriptToEmailAddress(final SessionContext ctx, final BaseStore item, final String value)
	{
		item.setProperty(ctx, NovalnetCoreConstants.Attributes.BaseStore.NOVALNETVENDORSCRIPTTOEMAILADDRESS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>BaseStore.novalnetVendorscriptToEmailAddress</code> attribute. 
	 * @param value the novalnetVendorscriptToEmailAddress
	 */
	public void setNovalnetVendorscriptToEmailAddress(final BaseStore item, final String value)
	{
		setNovalnetVendorscriptToEmailAddress( getSession().getSessionContext(), item, value );
	}
	
}
