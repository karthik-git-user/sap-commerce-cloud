/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 28, 2020, 12:06:32 PM                   ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package de.hybris.novalnet.core.jalo;

import de.hybris.novalnet.core.constants.NovalnetCoreConstants;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import de.hybris.platform.paymentstandard.jalo.StandardPaymentMode;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.paymentstandard.jalo.StandardPaymentMode NovalnetEpsPaymentMode}.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedNovalnetEpsPaymentMode extends StandardPaymentMode
{
	/** Qualifier of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute **/
	public static final String NOVALNETTESTMODE = "novalnetTestMode";
	/** Qualifier of the <code>NovalnetEpsPaymentMode.novalnetEndUserInfo</code> attribute **/
	public static final String NOVALNETENDUSERINFO = "novalnetEndUserInfo";
	/** Qualifier of the <code>NovalnetEpsPaymentMode.novalnetOrderSuccessStatus</code> attribute **/
	public static final String NOVALNETORDERSUCCESSSTATUS = "novalnetOrderSuccessStatus";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(StandardPaymentMode.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(NOVALNETTESTMODE, AttributeMode.INITIAL);
		tmp.put(NOVALNETENDUSERINFO, AttributeMode.INITIAL);
		tmp.put(NOVALNETORDERSUCCESSSTATUS, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetEpsPaymentMode.novalnetEndUserInfo</code> attribute.
	 * @return the novalnetEndUserInfo
	 */
	public String getNovalnetEndUserInfo(final SessionContext ctx)
	{
		return (String)getProperty( ctx, NOVALNETENDUSERINFO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetEpsPaymentMode.novalnetEndUserInfo</code> attribute.
	 * @return the novalnetEndUserInfo
	 */
	public String getNovalnetEndUserInfo()
	{
		return getNovalnetEndUserInfo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetEpsPaymentMode.novalnetEndUserInfo</code> attribute. 
	 * @param value the novalnetEndUserInfo
	 */
	public void setNovalnetEndUserInfo(final SessionContext ctx, final String value)
	{
		setProperty(ctx, NOVALNETENDUSERINFO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetEpsPaymentMode.novalnetEndUserInfo</code> attribute. 
	 * @param value the novalnetEndUserInfo
	 */
	public void setNovalnetEndUserInfo(final String value)
	{
		setNovalnetEndUserInfo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetEpsPaymentMode.novalnetOrderSuccessStatus</code> attribute.
	 * @return the novalnetOrderSuccessStatus
	 */
	public EnumerationValue getNovalnetOrderSuccessStatus(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, NOVALNETORDERSUCCESSSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetEpsPaymentMode.novalnetOrderSuccessStatus</code> attribute.
	 * @return the novalnetOrderSuccessStatus
	 */
	public EnumerationValue getNovalnetOrderSuccessStatus()
	{
		return getNovalnetOrderSuccessStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetEpsPaymentMode.novalnetOrderSuccessStatus</code> attribute. 
	 * @param value the novalnetOrderSuccessStatus
	 */
	public void setNovalnetOrderSuccessStatus(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, NOVALNETORDERSUCCESSSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetEpsPaymentMode.novalnetOrderSuccessStatus</code> attribute. 
	 * @param value the novalnetOrderSuccessStatus
	 */
	public void setNovalnetOrderSuccessStatus(final EnumerationValue value)
	{
		setNovalnetOrderSuccessStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute.
	 * @return the novalnetTestMode
	 */
	public Boolean isNovalnetTestMode(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, NOVALNETTESTMODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute.
	 * @return the novalnetTestMode
	 */
	public Boolean isNovalnetTestMode()
	{
		return isNovalnetTestMode( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute. 
	 * @return the novalnetTestMode
	 */
	public boolean isNovalnetTestModeAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isNovalnetTestMode( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute. 
	 * @return the novalnetTestMode
	 */
	public boolean isNovalnetTestModeAsPrimitive()
	{
		return isNovalnetTestModeAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, NOVALNETTESTMODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final Boolean value)
	{
		setNovalnetTestMode( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final SessionContext ctx, final boolean value)
	{
		setNovalnetTestMode( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetEpsPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final boolean value)
	{
		setNovalnetTestMode( getSession().getSessionContext(), value );
	}
	
}
