/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 28, 2020, 12:06:32 PM                   ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package de.hybris.novalnet.core.jalo;

import de.hybris.novalnet.core.constants.NovalnetCoreConstants;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import de.hybris.platform.paymentstandard.jalo.StandardPaymentMode;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.paymentstandard.jalo.StandardPaymentMode NovalnetGuaranteedDirectDebitSepaPaymentMode}.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedNovalnetGuaranteedDirectDebitSepaPaymentMode extends StandardPaymentMode
{
	/** Qualifier of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute **/
	public static final String NOVALNETTESTMODE = "novalnetTestMode";
	/** Qualifier of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetEndUserInfo</code> attribute **/
	public static final String NOVALNETENDUSERINFO = "novalnetEndUserInfo";
	/** Qualifier of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute **/
	public static final String NOVALNETDUEDATE = "novalnetDueDate";
	/** Qualifier of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOrderSuccessStatus</code> attribute **/
	public static final String NOVALNETORDERSUCCESSSTATUS = "novalnetOrderSuccessStatus";
	/** Qualifier of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute **/
	public static final String NOVALNETMINIMUMGUARANTEEAMOUNT = "novalnetMinimumGuaranteeAmount";
	/** Qualifier of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAction</code> attribute **/
	public static final String NOVALNETONHOLDACTION = "novalnetOnholdAction";
	/** Qualifier of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute **/
	public static final String NOVALNETONHOLDAMOUNT = "novalnetOnholdAmount";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(StandardPaymentMode.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(NOVALNETTESTMODE, AttributeMode.INITIAL);
		tmp.put(NOVALNETENDUSERINFO, AttributeMode.INITIAL);
		tmp.put(NOVALNETDUEDATE, AttributeMode.INITIAL);
		tmp.put(NOVALNETORDERSUCCESSSTATUS, AttributeMode.INITIAL);
		tmp.put(NOVALNETMINIMUMGUARANTEEAMOUNT, AttributeMode.INITIAL);
		tmp.put(NOVALNETONHOLDACTION, AttributeMode.INITIAL);
		tmp.put(NOVALNETONHOLDAMOUNT, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute.
	 * @return the novalnetDueDate
	 */
	public Integer getNovalnetDueDate(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, NOVALNETDUEDATE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute.
	 * @return the novalnetDueDate
	 */
	public Integer getNovalnetDueDate()
	{
		return getNovalnetDueDate( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute. 
	 * @return the novalnetDueDate
	 */
	public int getNovalnetDueDateAsPrimitive(final SessionContext ctx)
	{
		Integer value = getNovalnetDueDate( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute. 
	 * @return the novalnetDueDate
	 */
	public int getNovalnetDueDateAsPrimitive()
	{
		return getNovalnetDueDateAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute. 
	 * @param value the novalnetDueDate
	 */
	public void setNovalnetDueDate(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, NOVALNETDUEDATE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute. 
	 * @param value the novalnetDueDate
	 */
	public void setNovalnetDueDate(final Integer value)
	{
		setNovalnetDueDate( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute. 
	 * @param value the novalnetDueDate
	 */
	public void setNovalnetDueDate(final SessionContext ctx, final int value)
	{
		setNovalnetDueDate( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetDueDate</code> attribute. 
	 * @param value the novalnetDueDate
	 */
	public void setNovalnetDueDate(final int value)
	{
		setNovalnetDueDate( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetEndUserInfo</code> attribute.
	 * @return the novalnetEndUserInfo
	 */
	public String getNovalnetEndUserInfo(final SessionContext ctx)
	{
		return (String)getProperty( ctx, NOVALNETENDUSERINFO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetEndUserInfo</code> attribute.
	 * @return the novalnetEndUserInfo
	 */
	public String getNovalnetEndUserInfo()
	{
		return getNovalnetEndUserInfo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetEndUserInfo</code> attribute. 
	 * @param value the novalnetEndUserInfo
	 */
	public void setNovalnetEndUserInfo(final SessionContext ctx, final String value)
	{
		setProperty(ctx, NOVALNETENDUSERINFO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetEndUserInfo</code> attribute. 
	 * @param value the novalnetEndUserInfo
	 */
	public void setNovalnetEndUserInfo(final String value)
	{
		setNovalnetEndUserInfo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute.
	 * @return the novalnetMinimumGuaranteeAmount
	 */
	public Integer getNovalnetMinimumGuaranteeAmount(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, NOVALNETMINIMUMGUARANTEEAMOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute.
	 * @return the novalnetMinimumGuaranteeAmount
	 */
	public Integer getNovalnetMinimumGuaranteeAmount()
	{
		return getNovalnetMinimumGuaranteeAmount( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute. 
	 * @return the novalnetMinimumGuaranteeAmount
	 */
	public int getNovalnetMinimumGuaranteeAmountAsPrimitive(final SessionContext ctx)
	{
		Integer value = getNovalnetMinimumGuaranteeAmount( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute. 
	 * @return the novalnetMinimumGuaranteeAmount
	 */
	public int getNovalnetMinimumGuaranteeAmountAsPrimitive()
	{
		return getNovalnetMinimumGuaranteeAmountAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute. 
	 * @param value the novalnetMinimumGuaranteeAmount
	 */
	public void setNovalnetMinimumGuaranteeAmount(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, NOVALNETMINIMUMGUARANTEEAMOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute. 
	 * @param value the novalnetMinimumGuaranteeAmount
	 */
	public void setNovalnetMinimumGuaranteeAmount(final Integer value)
	{
		setNovalnetMinimumGuaranteeAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute. 
	 * @param value the novalnetMinimumGuaranteeAmount
	 */
	public void setNovalnetMinimumGuaranteeAmount(final SessionContext ctx, final int value)
	{
		setNovalnetMinimumGuaranteeAmount( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetMinimumGuaranteeAmount</code> attribute. 
	 * @param value the novalnetMinimumGuaranteeAmount
	 */
	public void setNovalnetMinimumGuaranteeAmount(final int value)
	{
		setNovalnetMinimumGuaranteeAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAction</code> attribute.
	 * @return the novalnetOnholdAction
	 */
	public EnumerationValue getNovalnetOnholdAction(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, NOVALNETONHOLDACTION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAction</code> attribute.
	 * @return the novalnetOnholdAction
	 */
	public EnumerationValue getNovalnetOnholdAction()
	{
		return getNovalnetOnholdAction( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAction</code> attribute. 
	 * @param value the novalnetOnholdAction
	 */
	public void setNovalnetOnholdAction(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, NOVALNETONHOLDACTION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAction</code> attribute. 
	 * @param value the novalnetOnholdAction
	 */
	public void setNovalnetOnholdAction(final EnumerationValue value)
	{
		setNovalnetOnholdAction( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute.
	 * @return the novalnetOnholdAmount
	 */
	public Integer getNovalnetOnholdAmount(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, NOVALNETONHOLDAMOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute.
	 * @return the novalnetOnholdAmount
	 */
	public Integer getNovalnetOnholdAmount()
	{
		return getNovalnetOnholdAmount( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @return the novalnetOnholdAmount
	 */
	public int getNovalnetOnholdAmountAsPrimitive(final SessionContext ctx)
	{
		Integer value = getNovalnetOnholdAmount( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @return the novalnetOnholdAmount
	 */
	public int getNovalnetOnholdAmountAsPrimitive()
	{
		return getNovalnetOnholdAmountAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @param value the novalnetOnholdAmount
	 */
	public void setNovalnetOnholdAmount(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, NOVALNETONHOLDAMOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @param value the novalnetOnholdAmount
	 */
	public void setNovalnetOnholdAmount(final Integer value)
	{
		setNovalnetOnholdAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @param value the novalnetOnholdAmount
	 */
	public void setNovalnetOnholdAmount(final SessionContext ctx, final int value)
	{
		setNovalnetOnholdAmount( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @param value the novalnetOnholdAmount
	 */
	public void setNovalnetOnholdAmount(final int value)
	{
		setNovalnetOnholdAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOrderSuccessStatus</code> attribute.
	 * @return the novalnetOrderSuccessStatus
	 */
	public EnumerationValue getNovalnetOrderSuccessStatus(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, NOVALNETORDERSUCCESSSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOrderSuccessStatus</code> attribute.
	 * @return the novalnetOrderSuccessStatus
	 */
	public EnumerationValue getNovalnetOrderSuccessStatus()
	{
		return getNovalnetOrderSuccessStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOrderSuccessStatus</code> attribute. 
	 * @param value the novalnetOrderSuccessStatus
	 */
	public void setNovalnetOrderSuccessStatus(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, NOVALNETORDERSUCCESSSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetOrderSuccessStatus</code> attribute. 
	 * @param value the novalnetOrderSuccessStatus
	 */
	public void setNovalnetOrderSuccessStatus(final EnumerationValue value)
	{
		setNovalnetOrderSuccessStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute.
	 * @return the novalnetTestMode
	 */
	public Boolean isNovalnetTestMode(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, NOVALNETTESTMODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute.
	 * @return the novalnetTestMode
	 */
	public Boolean isNovalnetTestMode()
	{
		return isNovalnetTestMode( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute. 
	 * @return the novalnetTestMode
	 */
	public boolean isNovalnetTestModeAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isNovalnetTestMode( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute. 
	 * @return the novalnetTestMode
	 */
	public boolean isNovalnetTestModeAsPrimitive()
	{
		return isNovalnetTestModeAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, NOVALNETTESTMODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final Boolean value)
	{
		setNovalnetTestMode( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final SessionContext ctx, final boolean value)
	{
		setNovalnetTestMode( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetGuaranteedDirectDebitSepaPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final boolean value)
	{
		setNovalnetTestMode( getSession().getSessionContext(), value );
	}
	
}
