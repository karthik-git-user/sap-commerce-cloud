/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 28, 2020, 12:06:32 PM                   ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package de.hybris.novalnet.core.jalo;

import de.hybris.novalnet.core.constants.NovalnetCoreConstants;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.enumeration.EnumerationValue;
import de.hybris.platform.paymentstandard.jalo.StandardPaymentMode;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.paymentstandard.jalo.StandardPaymentMode NovalnetCreditCardPaymentMode}.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedNovalnetCreditCardPaymentMode extends StandardPaymentMode
{
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute **/
	public static final String NOVALNETTESTMODE = "novalnetTestMode";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetEndUserInfo</code> attribute **/
	public static final String NOVALNETENDUSERINFO = "novalnetEndUserInfo";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetOrderSuccessStatus</code> attribute **/
	public static final String NOVALNETORDERSUCCESSSTATUS = "novalnetOrderSuccessStatus";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAction</code> attribute **/
	public static final String NOVALNETONHOLDACTION = "novalnetOnholdAction";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute **/
	public static final String NOVALNETONHOLDAMOUNT = "novalnetOnholdAmount";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute **/
	public static final String NOVALNET3DSECURE = "novalnet3dSecure";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute **/
	public static final String NOVALNETAMEXLOGO = "novalnetAmexLogo";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute **/
	public static final String NOVALNETINLINECC = "novalnetInlineCC";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute **/
	public static final String NOVALNETONECLICKSHOPPING = "novalnetOneClickShopping";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetStandardLabelCss</code> attribute **/
	public static final String NOVALNETSTANDARDLABELCSS = "novalnetStandardLabelCss";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetStandardInputCss</code> attribute **/
	public static final String NOVALNETSTANDARDINPUTCSS = "novalnetStandardInputCss";
	/** Qualifier of the <code>NovalnetCreditCardPaymentMode.novalnetStandardCss</code> attribute **/
	public static final String NOVALNETSTANDARDCSS = "novalnetStandardCss";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>(StandardPaymentMode.DEFAULT_INITIAL_ATTRIBUTES);
		tmp.put(NOVALNETTESTMODE, AttributeMode.INITIAL);
		tmp.put(NOVALNETENDUSERINFO, AttributeMode.INITIAL);
		tmp.put(NOVALNETORDERSUCCESSSTATUS, AttributeMode.INITIAL);
		tmp.put(NOVALNETONHOLDACTION, AttributeMode.INITIAL);
		tmp.put(NOVALNETONHOLDAMOUNT, AttributeMode.INITIAL);
		tmp.put(NOVALNET3DSECURE, AttributeMode.INITIAL);
		tmp.put(NOVALNETAMEXLOGO, AttributeMode.INITIAL);
		tmp.put(NOVALNETINLINECC, AttributeMode.INITIAL);
		tmp.put(NOVALNETONECLICKSHOPPING, AttributeMode.INITIAL);
		tmp.put(NOVALNETSTANDARDLABELCSS, AttributeMode.INITIAL);
		tmp.put(NOVALNETSTANDARDINPUTCSS, AttributeMode.INITIAL);
		tmp.put(NOVALNETSTANDARDCSS, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute.
	 * @return the novalnet3dSecure
	 */
	public Boolean isNovalnet3dSecure(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, NOVALNET3DSECURE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute.
	 * @return the novalnet3dSecure
	 */
	public Boolean isNovalnet3dSecure()
	{
		return isNovalnet3dSecure( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute. 
	 * @return the novalnet3dSecure
	 */
	public boolean isNovalnet3dSecureAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isNovalnet3dSecure( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute. 
	 * @return the novalnet3dSecure
	 */
	public boolean isNovalnet3dSecureAsPrimitive()
	{
		return isNovalnet3dSecureAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute. 
	 * @param value the novalnet3dSecure
	 */
	public void setNovalnet3dSecure(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, NOVALNET3DSECURE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute. 
	 * @param value the novalnet3dSecure
	 */
	public void setNovalnet3dSecure(final Boolean value)
	{
		setNovalnet3dSecure( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute. 
	 * @param value the novalnet3dSecure
	 */
	public void setNovalnet3dSecure(final SessionContext ctx, final boolean value)
	{
		setNovalnet3dSecure( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnet3dSecure</code> attribute. 
	 * @param value the novalnet3dSecure
	 */
	public void setNovalnet3dSecure(final boolean value)
	{
		setNovalnet3dSecure( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute.
	 * @return the novalnetAmexLogo
	 */
	public Boolean isNovalnetAmexLogo(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, NOVALNETAMEXLOGO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute.
	 * @return the novalnetAmexLogo
	 */
	public Boolean isNovalnetAmexLogo()
	{
		return isNovalnetAmexLogo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute. 
	 * @return the novalnetAmexLogo
	 */
	public boolean isNovalnetAmexLogoAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isNovalnetAmexLogo( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute. 
	 * @return the novalnetAmexLogo
	 */
	public boolean isNovalnetAmexLogoAsPrimitive()
	{
		return isNovalnetAmexLogoAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute. 
	 * @param value the novalnetAmexLogo
	 */
	public void setNovalnetAmexLogo(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, NOVALNETAMEXLOGO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute. 
	 * @param value the novalnetAmexLogo
	 */
	public void setNovalnetAmexLogo(final Boolean value)
	{
		setNovalnetAmexLogo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute. 
	 * @param value the novalnetAmexLogo
	 */
	public void setNovalnetAmexLogo(final SessionContext ctx, final boolean value)
	{
		setNovalnetAmexLogo( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetAmexLogo</code> attribute. 
	 * @param value the novalnetAmexLogo
	 */
	public void setNovalnetAmexLogo(final boolean value)
	{
		setNovalnetAmexLogo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetEndUserInfo</code> attribute.
	 * @return the novalnetEndUserInfo
	 */
	public String getNovalnetEndUserInfo(final SessionContext ctx)
	{
		return (String)getProperty( ctx, NOVALNETENDUSERINFO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetEndUserInfo</code> attribute.
	 * @return the novalnetEndUserInfo
	 */
	public String getNovalnetEndUserInfo()
	{
		return getNovalnetEndUserInfo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetEndUserInfo</code> attribute. 
	 * @param value the novalnetEndUserInfo
	 */
	public void setNovalnetEndUserInfo(final SessionContext ctx, final String value)
	{
		setProperty(ctx, NOVALNETENDUSERINFO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetEndUserInfo</code> attribute. 
	 * @param value the novalnetEndUserInfo
	 */
	public void setNovalnetEndUserInfo(final String value)
	{
		setNovalnetEndUserInfo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute.
	 * @return the novalnetInlineCC
	 */
	public Boolean isNovalnetInlineCC(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, NOVALNETINLINECC);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute.
	 * @return the novalnetInlineCC
	 */
	public Boolean isNovalnetInlineCC()
	{
		return isNovalnetInlineCC( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute. 
	 * @return the novalnetInlineCC
	 */
	public boolean isNovalnetInlineCCAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isNovalnetInlineCC( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute. 
	 * @return the novalnetInlineCC
	 */
	public boolean isNovalnetInlineCCAsPrimitive()
	{
		return isNovalnetInlineCCAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute. 
	 * @param value the novalnetInlineCC
	 */
	public void setNovalnetInlineCC(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, NOVALNETINLINECC,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute. 
	 * @param value the novalnetInlineCC
	 */
	public void setNovalnetInlineCC(final Boolean value)
	{
		setNovalnetInlineCC( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute. 
	 * @param value the novalnetInlineCC
	 */
	public void setNovalnetInlineCC(final SessionContext ctx, final boolean value)
	{
		setNovalnetInlineCC( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetInlineCC</code> attribute. 
	 * @param value the novalnetInlineCC
	 */
	public void setNovalnetInlineCC(final boolean value)
	{
		setNovalnetInlineCC( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute.
	 * @return the novalnetOneClickShopping
	 */
	public Boolean isNovalnetOneClickShopping(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, NOVALNETONECLICKSHOPPING);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute.
	 * @return the novalnetOneClickShopping
	 */
	public Boolean isNovalnetOneClickShopping()
	{
		return isNovalnetOneClickShopping( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute. 
	 * @return the novalnetOneClickShopping
	 */
	public boolean isNovalnetOneClickShoppingAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isNovalnetOneClickShopping( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute. 
	 * @return the novalnetOneClickShopping
	 */
	public boolean isNovalnetOneClickShoppingAsPrimitive()
	{
		return isNovalnetOneClickShoppingAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute. 
	 * @param value the novalnetOneClickShopping
	 */
	public void setNovalnetOneClickShopping(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, NOVALNETONECLICKSHOPPING,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute. 
	 * @param value the novalnetOneClickShopping
	 */
	public void setNovalnetOneClickShopping(final Boolean value)
	{
		setNovalnetOneClickShopping( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute. 
	 * @param value the novalnetOneClickShopping
	 */
	public void setNovalnetOneClickShopping(final SessionContext ctx, final boolean value)
	{
		setNovalnetOneClickShopping( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOneClickShopping</code> attribute. 
	 * @param value the novalnetOneClickShopping
	 */
	public void setNovalnetOneClickShopping(final boolean value)
	{
		setNovalnetOneClickShopping( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAction</code> attribute.
	 * @return the novalnetOnholdAction
	 */
	public EnumerationValue getNovalnetOnholdAction(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, NOVALNETONHOLDACTION);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAction</code> attribute.
	 * @return the novalnetOnholdAction
	 */
	public EnumerationValue getNovalnetOnholdAction()
	{
		return getNovalnetOnholdAction( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAction</code> attribute. 
	 * @param value the novalnetOnholdAction
	 */
	public void setNovalnetOnholdAction(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, NOVALNETONHOLDACTION,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAction</code> attribute. 
	 * @param value the novalnetOnholdAction
	 */
	public void setNovalnetOnholdAction(final EnumerationValue value)
	{
		setNovalnetOnholdAction( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute.
	 * @return the novalnetOnholdAmount
	 */
	public Integer getNovalnetOnholdAmount(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, NOVALNETONHOLDAMOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute.
	 * @return the novalnetOnholdAmount
	 */
	public Integer getNovalnetOnholdAmount()
	{
		return getNovalnetOnholdAmount( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @return the novalnetOnholdAmount
	 */
	public int getNovalnetOnholdAmountAsPrimitive(final SessionContext ctx)
	{
		Integer value = getNovalnetOnholdAmount( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @return the novalnetOnholdAmount
	 */
	public int getNovalnetOnholdAmountAsPrimitive()
	{
		return getNovalnetOnholdAmountAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @param value the novalnetOnholdAmount
	 */
	public void setNovalnetOnholdAmount(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, NOVALNETONHOLDAMOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @param value the novalnetOnholdAmount
	 */
	public void setNovalnetOnholdAmount(final Integer value)
	{
		setNovalnetOnholdAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @param value the novalnetOnholdAmount
	 */
	public void setNovalnetOnholdAmount(final SessionContext ctx, final int value)
	{
		setNovalnetOnholdAmount( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOnholdAmount</code> attribute. 
	 * @param value the novalnetOnholdAmount
	 */
	public void setNovalnetOnholdAmount(final int value)
	{
		setNovalnetOnholdAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOrderSuccessStatus</code> attribute.
	 * @return the novalnetOrderSuccessStatus
	 */
	public EnumerationValue getNovalnetOrderSuccessStatus(final SessionContext ctx)
	{
		return (EnumerationValue)getProperty( ctx, NOVALNETORDERSUCCESSSTATUS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetOrderSuccessStatus</code> attribute.
	 * @return the novalnetOrderSuccessStatus
	 */
	public EnumerationValue getNovalnetOrderSuccessStatus()
	{
		return getNovalnetOrderSuccessStatus( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOrderSuccessStatus</code> attribute. 
	 * @param value the novalnetOrderSuccessStatus
	 */
	public void setNovalnetOrderSuccessStatus(final SessionContext ctx, final EnumerationValue value)
	{
		setProperty(ctx, NOVALNETORDERSUCCESSSTATUS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetOrderSuccessStatus</code> attribute. 
	 * @param value the novalnetOrderSuccessStatus
	 */
	public void setNovalnetOrderSuccessStatus(final EnumerationValue value)
	{
		setNovalnetOrderSuccessStatus( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardCss</code> attribute.
	 * @return the novalnetStandardCss
	 */
	public String getNovalnetStandardCss(final SessionContext ctx)
	{
		return (String)getProperty( ctx, NOVALNETSTANDARDCSS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardCss</code> attribute.
	 * @return the novalnetStandardCss
	 */
	public String getNovalnetStandardCss()
	{
		return getNovalnetStandardCss( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardCss</code> attribute. 
	 * @param value the novalnetStandardCss
	 */
	public void setNovalnetStandardCss(final SessionContext ctx, final String value)
	{
		setProperty(ctx, NOVALNETSTANDARDCSS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardCss</code> attribute. 
	 * @param value the novalnetStandardCss
	 */
	public void setNovalnetStandardCss(final String value)
	{
		setNovalnetStandardCss( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardInputCss</code> attribute.
	 * @return the novalnetStandardInputCss
	 */
	public String getNovalnetStandardInputCss(final SessionContext ctx)
	{
		return (String)getProperty( ctx, NOVALNETSTANDARDINPUTCSS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardInputCss</code> attribute.
	 * @return the novalnetStandardInputCss
	 */
	public String getNovalnetStandardInputCss()
	{
		return getNovalnetStandardInputCss( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardInputCss</code> attribute. 
	 * @param value the novalnetStandardInputCss
	 */
	public void setNovalnetStandardInputCss(final SessionContext ctx, final String value)
	{
		setProperty(ctx, NOVALNETSTANDARDINPUTCSS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardInputCss</code> attribute. 
	 * @param value the novalnetStandardInputCss
	 */
	public void setNovalnetStandardInputCss(final String value)
	{
		setNovalnetStandardInputCss( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardLabelCss</code> attribute.
	 * @return the novalnetStandardLabelCss
	 */
	public String getNovalnetStandardLabelCss(final SessionContext ctx)
	{
		return (String)getProperty( ctx, NOVALNETSTANDARDLABELCSS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardLabelCss</code> attribute.
	 * @return the novalnetStandardLabelCss
	 */
	public String getNovalnetStandardLabelCss()
	{
		return getNovalnetStandardLabelCss( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardLabelCss</code> attribute. 
	 * @param value the novalnetStandardLabelCss
	 */
	public void setNovalnetStandardLabelCss(final SessionContext ctx, final String value)
	{
		setProperty(ctx, NOVALNETSTANDARDLABELCSS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetStandardLabelCss</code> attribute. 
	 * @param value the novalnetStandardLabelCss
	 */
	public void setNovalnetStandardLabelCss(final String value)
	{
		setNovalnetStandardLabelCss( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute.
	 * @return the novalnetTestMode
	 */
	public Boolean isNovalnetTestMode(final SessionContext ctx)
	{
		return (Boolean)getProperty( ctx, NOVALNETTESTMODE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute.
	 * @return the novalnetTestMode
	 */
	public Boolean isNovalnetTestMode()
	{
		return isNovalnetTestMode( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute. 
	 * @return the novalnetTestMode
	 */
	public boolean isNovalnetTestModeAsPrimitive(final SessionContext ctx)
	{
		Boolean value = isNovalnetTestMode( ctx );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute. 
	 * @return the novalnetTestMode
	 */
	public boolean isNovalnetTestModeAsPrimitive()
	{
		return isNovalnetTestModeAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final SessionContext ctx, final Boolean value)
	{
		setProperty(ctx, NOVALNETTESTMODE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final Boolean value)
	{
		setNovalnetTestMode( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final SessionContext ctx, final boolean value)
	{
		setNovalnetTestMode( ctx,Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCreditCardPaymentMode.novalnetTestMode</code> attribute. 
	 * @param value the novalnetTestMode
	 */
	public void setNovalnetTestMode(final boolean value)
	{
		setNovalnetTestMode( getSession().getSessionContext(), value );
	}
	
}
