/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 28, 2020, 12:06:32 PM                   ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package de.hybris.novalnet.core.jalo;

import de.hybris.novalnet.core.constants.NovalnetCoreConstants;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.SessionContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type {@link de.hybris.platform.jalo.GenericItem NovalnetCallbackInfo}.
 */
@SuppressWarnings({"deprecation","unused","cast"})
public abstract class GeneratedNovalnetCallbackInfo extends GenericItem
{
	/** Qualifier of the <code>NovalnetCallbackInfo.paymentType</code> attribute **/
	public static final String PAYMENTTYPE = "paymentType";
	/** Qualifier of the <code>NovalnetCallbackInfo.callbackTid</code> attribute **/
	public static final String CALLBACKTID = "callbackTid";
	/** Qualifier of the <code>NovalnetCallbackInfo.orginalTid</code> attribute **/
	public static final String ORGINALTID = "orginalTid";
	/** Qualifier of the <code>NovalnetCallbackInfo.paidAmount</code> attribute **/
	public static final String PAIDAMOUNT = "paidAmount";
	/** Qualifier of the <code>NovalnetCallbackInfo.orderAmount</code> attribute **/
	public static final String ORDERAMOUNT = "orderAmount";
	/** Qualifier of the <code>NovalnetCallbackInfo.orderNo</code> attribute **/
	public static final String ORDERNO = "orderNo";
	protected static final Map<String, AttributeMode> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put(PAYMENTTYPE, AttributeMode.INITIAL);
		tmp.put(CALLBACKTID, AttributeMode.INITIAL);
		tmp.put(ORGINALTID, AttributeMode.INITIAL);
		tmp.put(PAIDAMOUNT, AttributeMode.INITIAL);
		tmp.put(ORDERAMOUNT, AttributeMode.INITIAL);
		tmp.put(ORDERNO, AttributeMode.INITIAL);
		DEFAULT_INITIAL_ATTRIBUTES = Collections.unmodifiableMap(tmp);
	}
	@Override
	protected Map<String, AttributeMode> getDefaultAttributeModes()
	{
		return DEFAULT_INITIAL_ATTRIBUTES;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.callbackTid</code> attribute.
	 * @return the callbackTid
	 */
	public Long getCallbackTid(final SessionContext ctx)
	{
		return (Long)getProperty( ctx, CALLBACKTID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.callbackTid</code> attribute.
	 * @return the callbackTid
	 */
	public Long getCallbackTid()
	{
		return getCallbackTid( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.callbackTid</code> attribute. 
	 * @return the callbackTid
	 */
	public long getCallbackTidAsPrimitive(final SessionContext ctx)
	{
		Long value = getCallbackTid( ctx );
		return value != null ? value.longValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.callbackTid</code> attribute. 
	 * @return the callbackTid
	 */
	public long getCallbackTidAsPrimitive()
	{
		return getCallbackTidAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.callbackTid</code> attribute. 
	 * @param value the callbackTid
	 */
	public void setCallbackTid(final SessionContext ctx, final Long value)
	{
		setProperty(ctx, CALLBACKTID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.callbackTid</code> attribute. 
	 * @param value the callbackTid
	 */
	public void setCallbackTid(final Long value)
	{
		setCallbackTid( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.callbackTid</code> attribute. 
	 * @param value the callbackTid
	 */
	public void setCallbackTid(final SessionContext ctx, final long value)
	{
		setCallbackTid( ctx,Long.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.callbackTid</code> attribute. 
	 * @param value the callbackTid
	 */
	public void setCallbackTid(final long value)
	{
		setCallbackTid( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orderAmount</code> attribute.
	 * @return the orderAmount
	 */
	public Integer getOrderAmount(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, ORDERAMOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orderAmount</code> attribute.
	 * @return the orderAmount
	 */
	public Integer getOrderAmount()
	{
		return getOrderAmount( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orderAmount</code> attribute. 
	 * @return the orderAmount
	 */
	public int getOrderAmountAsPrimitive(final SessionContext ctx)
	{
		Integer value = getOrderAmount( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orderAmount</code> attribute. 
	 * @return the orderAmount
	 */
	public int getOrderAmountAsPrimitive()
	{
		return getOrderAmountAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orderAmount</code> attribute. 
	 * @param value the orderAmount
	 */
	public void setOrderAmount(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, ORDERAMOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orderAmount</code> attribute. 
	 * @param value the orderAmount
	 */
	public void setOrderAmount(final Integer value)
	{
		setOrderAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orderAmount</code> attribute. 
	 * @param value the orderAmount
	 */
	public void setOrderAmount(final SessionContext ctx, final int value)
	{
		setOrderAmount( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orderAmount</code> attribute. 
	 * @param value the orderAmount
	 */
	public void setOrderAmount(final int value)
	{
		setOrderAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orderNo</code> attribute.
	 * @return the orderNo
	 */
	public String getOrderNo(final SessionContext ctx)
	{
		return (String)getProperty( ctx, ORDERNO);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orderNo</code> attribute.
	 * @return the orderNo
	 */
	public String getOrderNo()
	{
		return getOrderNo( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orderNo</code> attribute. 
	 * @param value the orderNo
	 */
	public void setOrderNo(final SessionContext ctx, final String value)
	{
		setProperty(ctx, ORDERNO,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orderNo</code> attribute. 
	 * @param value the orderNo
	 */
	public void setOrderNo(final String value)
	{
		setOrderNo( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orginalTid</code> attribute.
	 * @return the orginalTid
	 */
	public Long getOrginalTid(final SessionContext ctx)
	{
		return (Long)getProperty( ctx, ORGINALTID);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orginalTid</code> attribute.
	 * @return the orginalTid
	 */
	public Long getOrginalTid()
	{
		return getOrginalTid( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orginalTid</code> attribute. 
	 * @return the orginalTid
	 */
	public long getOrginalTidAsPrimitive(final SessionContext ctx)
	{
		Long value = getOrginalTid( ctx );
		return value != null ? value.longValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.orginalTid</code> attribute. 
	 * @return the orginalTid
	 */
	public long getOrginalTidAsPrimitive()
	{
		return getOrginalTidAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orginalTid</code> attribute. 
	 * @param value the orginalTid
	 */
	public void setOrginalTid(final SessionContext ctx, final Long value)
	{
		setProperty(ctx, ORGINALTID,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orginalTid</code> attribute. 
	 * @param value the orginalTid
	 */
	public void setOrginalTid(final Long value)
	{
		setOrginalTid( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orginalTid</code> attribute. 
	 * @param value the orginalTid
	 */
	public void setOrginalTid(final SessionContext ctx, final long value)
	{
		setOrginalTid( ctx,Long.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.orginalTid</code> attribute. 
	 * @param value the orginalTid
	 */
	public void setOrginalTid(final long value)
	{
		setOrginalTid( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.paidAmount</code> attribute.
	 * @return the paidAmount
	 */
	public Integer getPaidAmount(final SessionContext ctx)
	{
		return (Integer)getProperty( ctx, PAIDAMOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.paidAmount</code> attribute.
	 * @return the paidAmount
	 */
	public Integer getPaidAmount()
	{
		return getPaidAmount( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.paidAmount</code> attribute. 
	 * @return the paidAmount
	 */
	public int getPaidAmountAsPrimitive(final SessionContext ctx)
	{
		Integer value = getPaidAmount( ctx );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.paidAmount</code> attribute. 
	 * @return the paidAmount
	 */
	public int getPaidAmountAsPrimitive()
	{
		return getPaidAmountAsPrimitive( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.paidAmount</code> attribute. 
	 * @param value the paidAmount
	 */
	public void setPaidAmount(final SessionContext ctx, final Integer value)
	{
		setProperty(ctx, PAIDAMOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.paidAmount</code> attribute. 
	 * @param value the paidAmount
	 */
	public void setPaidAmount(final Integer value)
	{
		setPaidAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.paidAmount</code> attribute. 
	 * @param value the paidAmount
	 */
	public void setPaidAmount(final SessionContext ctx, final int value)
	{
		setPaidAmount( ctx,Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.paidAmount</code> attribute. 
	 * @param value the paidAmount
	 */
	public void setPaidAmount(final int value)
	{
		setPaidAmount( getSession().getSessionContext(), value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.paymentType</code> attribute.
	 * @return the paymentType
	 */
	public String getPaymentType(final SessionContext ctx)
	{
		return (String)getProperty( ctx, PAYMENTTYPE);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>NovalnetCallbackInfo.paymentType</code> attribute.
	 * @return the paymentType
	 */
	public String getPaymentType()
	{
		return getPaymentType( getSession().getSessionContext() );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.paymentType</code> attribute. 
	 * @param value the paymentType
	 */
	public void setPaymentType(final SessionContext ctx, final String value)
	{
		setProperty(ctx, PAYMENTTYPE,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>NovalnetCallbackInfo.paymentType</code> attribute. 
	 * @param value the paymentType
	 */
	public void setPaymentType(final String value)
	{
		setPaymentType( getSession().getSessionContext(), value );
	}
	
}
