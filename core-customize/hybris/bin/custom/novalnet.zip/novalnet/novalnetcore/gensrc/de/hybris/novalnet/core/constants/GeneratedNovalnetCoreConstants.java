/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 28, 2020, 12:06:32 PM                   ---
 * ----------------------------------------------------------------
 *  
 * [y] hybris Platform
 * Copyright (c) 2020 SAP SE or an SAP affiliate company. All rights reserved.
 * This software is the confidential and proprietary information of SAP
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the
 * license agreement you entered into with SAP.
 */
package de.hybris.novalnet.core.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast"})
public class GeneratedNovalnetCoreConstants
{
	public static final String EXTENSIONNAME = "novalnetcore";
	public static class TC
	{
		public static final String NOVALNETBARZAHLENPAYMENTMODE = "NovalnetBarzahlenPaymentMode".intern();
		public static final String NOVALNETCALLBACKINFO = "NovalnetCallbackInfo".intern();
		public static final String NOVALNETCREDITCARDPAYMENTMODE = "NovalnetCreditCardPaymentMode".intern();
		public static final String NOVALNETDIRECTDEBITSEPAPAYMENTMODE = "NovalnetDirectDebitSepaPaymentMode".intern();
		public static final String NOVALNETEPSPAYMENTMODE = "NovalnetEpsPaymentMode".intern();
		public static final String NOVALNETGIROPAYPAYMENTMODE = "NovalnetGiropayPaymentMode".intern();
		public static final String NOVALNETGUARANTEEDDIRECTDEBITSEPAPAYMENTMODE = "NovalnetGuaranteedDirectDebitSepaPaymentMode".intern();
		public static final String NOVALNETGUARANTEEDINVOICEPAYMENTMODE = "NovalnetGuaranteedInvoicePaymentMode".intern();
		public static final String NOVALNETIDEALPAYMENTMODE = "NovalnetIdealPaymentMode".intern();
		public static final String NOVALNETINSTANTBANKTRANSFERPAYMENTMODE = "NovalnetInstantBankTransferPaymentMode".intern();
		public static final String NOVALNETINVOICEPAYMENTMODE = "NovalnetInvoicePaymentMode".intern();
		public static final String NOVALNETPAYMENTINFO = "NovalnetPaymentInfo".intern();
		public static final String NOVALNETPAYMENTREFINFO = "NovalnetPaymentRefInfo".intern();
		public static final String NOVALNETPAYPALPAYMENTMODE = "NovalnetPayPalPaymentMode".intern();
		public static final String NOVALNETPOSTFINANCECARDPAYMENTMODE = "NovalnetPostFinanceCardPaymentMode".intern();
		public static final String NOVALNETPOSTFINANCEPAYMENTMODE = "NovalnetPostFinancePaymentMode".intern();
		public static final String NOVALNETPREPAYMENTPAYMENTMODE = "NovalnetPrepaymentPaymentMode".intern();
		public static final String NOVALNETPRZELEWY24PAYMENTMODE = "NovalnetPrzelewy24PaymentMode".intern();
		public static final String ONHOLDACTIONTYPE = "OnholdActionType".intern();
	}
	public static class Attributes
	{
		public static class BaseStore
		{
			public static final String NOVALNETAPIKEY = "novalnetAPIKey".intern();
			public static final String NOVALNETCLIENTKEY = "novalnetClientKey".intern();
			public static final String NOVALNETPAYMENTACCESSKEY = "novalnetPaymentAccessKey".intern();
			public static final String NOVALNETPAYMENTLOGO = "novalnetPaymentLogo".intern();
			public static final String NOVALNETTARIFFID = "novalnetTariffId".intern();
			public static final String NOVALNETVENDORSCRIPTTESTMODE = "novalnetVendorscriptTestMode".intern();
			public static final String NOVALNETVENDORSCRIPTTOEMAILADDRESS = "novalnetVendorscriptToEmailAddress".intern();
		}
	}
	public static class Enumerations
	{
		public static class OnholdActionType
		{
			public static final String AUTHORIZE = "AUTHORIZE".intern();
			public static final String CAPTURE = "CAPTURE".intern();
		}
	}
	
	protected GeneratedNovalnetCoreConstants()
	{
		// private constructor
	}
	
	
}
