/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 28, 2020, 12:06:32 PM                   ---
 * ----------------------------------------------------------------
 */
package novalnet.novalnetcheckoutaddon.constants;

/**
 * @deprecated since ages - use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast"})
public class GeneratedNovalnetcheckoutaddonConstants
{
	public static final String EXTENSIONNAME = "novalnetcheckoutaddon";
	
	protected GeneratedNovalnetcheckoutaddonConstants()
	{
		// private constructor
	}
	
	
}
